#pragma once
#include "../Win32/atomic.h"