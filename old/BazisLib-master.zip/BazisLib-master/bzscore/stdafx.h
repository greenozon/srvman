// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#if defined(_DEBUG) && defined(_NDEBUG)
#error Both _DEBUG and _NDEBUG cannot be defined at the same time!
#endif

#include "cmndef.h"


// TODO: reference additional headers your program requires here
