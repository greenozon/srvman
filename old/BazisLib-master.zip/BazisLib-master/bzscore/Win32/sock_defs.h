#pragma once

namespace BazisLib
{
	namespace Network
	{
		typedef struct sockaddr_in _PlatformSpecificInternetAddress;
	}
}