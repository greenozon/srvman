#pragma once
#include <inttypes.h>

typedef uint64_t ULONGLONG;
typedef int64_t LONGLONG;