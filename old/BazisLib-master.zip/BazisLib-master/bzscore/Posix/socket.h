#pragma once
#undef BZSLIB_SOCKETS_AVAILABLE