#define INITGUID

#include "stdafx.h"
#ifdef BZSLIB_WINKERNEL
#endif