#pragma once

#define DISPATCH_ROUTINE_DECL __forceinline	//Dramatically reduces stack frame depth
#define DISPATCH_ROUTINE_OVERRIDE	//override
