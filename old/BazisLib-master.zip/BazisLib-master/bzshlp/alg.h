#pragma once
#include "cmndef.h"
#include "algorithms/filealgs.h"
#include "algorithms/memalgs.h"
