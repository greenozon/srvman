========================================================================
    STATIC LIBRARY : bzsnet Project Overview
========================================================================

This library contains various network-based classes, such as HTTP client
and multi-thread download manager

/////////////////////////////////////////////////////////////////////////////
