#pragma once
#include <bzscore/string.h>

class ProjectDescription
{
public:
	BazisLib::String SampleName;
	BazisLib::String SampleDescription;
	BazisLib::String INFFile;
};