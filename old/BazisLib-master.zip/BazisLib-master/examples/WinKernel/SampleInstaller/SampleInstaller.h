// SampleInstaller.h
