#pragma once

int RunCommandLineAsService(LPCTSTR lpCommandLineToRun, LPCTSTR lpServiceName);