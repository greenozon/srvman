#pragma once

extern const char szCommandLineHelpMsg[];
extern const char szPressAnyKey[];

int ConsoleMain(int argc, LPWSTR *pArgv, bool ConsoleExisted);