//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by srvman.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDR_MENU1                       201
#define IDI_DRIVER                      202
#define IDI_FSDRIVER                    203
#define IDI_GREEN                       204
#define IDI_GREY                        205
#define IDI_MULTISERV                   206
#define IDI_RED                         207
#define IDI_SERV                        208
#define IDI_YELLOW                      209
#define IDI_INTERACTIVE                 211
#define IDD_SERVICEPROPS                212
#define IDI_SYSTEM                      213
#define IDI_AUTO                        214
#define IDI_BOOT                        215
#define IDI_DISABLED                    216
#define IDI_ICON5                       217
#define IDI_MANUAL                      217
#define IDC_LIST1                       1000
#define IDC_PROPERTIES                  1001
#define IDC_STARTSTOP                   1002
#define IDC_RESTART                     1003
#define IDC_ADDSERVICE                  1007
#define IDC_DELETESERVICE               1008
#define IDC_INTERNALNAME                1008
#define IDC_EXIT                        1009
#define IDC_VISIBLENAME                 1009
#define IDC_WIN32PATH                   1010
#define IDC_TRANSLATEDPATH              1011
#define IDC_BUTTON1                     1012
#define IDC_SERVICETYPE                 1013
#define IDC_STARTMODE                   1014
#define IDC_LOADGROUP                   1015
#define IDC_INTERACTIVE                 1016
#define IDC_LOGIN                       1017
#define IDC_PASSWORD                    1018
#define IDC_BROWSE                      1019
#define IDC_DESCRIPTION                 1020
#define ID_FILE_EXIT                    32775
#define ID_SERVICE_START                32776
#define ID_SERVICE_STOP                 32777
#define ID_SERVICE_RESTART              32778
#define ID_CONTROL_START                32779
#define ID_CONTROL_STOP                 32780
#define ID_SERVICE_PROPERTIES           32781
#define ID_CONTROL_RESTART              32782
#define ID_SERVICE_ADDSERVICE           32783
#define ID_SERVICE_DELETESERVICE        32784
#define ID_HELP_ABOUT                   32785
#define ID_HELP_OPENPROJECTPAGE         32786
#define ID_HELP_                        32787
#define ID_VIEW_SERVICENAME             32788
#define ID_VIEW_SERVICE                 32789
#define ID_VIEW_TYPE                    32790
#define ID_VIEW_STATE                   32791
#define ID_VIEW_BINARYFILE              32792
#define ID_VIEW_STARTTYPE               32793
#define IDC_ABOUT                       32794
#define ID_HELP_COMMANDLINEHELP         32795
#define ID_VIEW_INTERNALNAME            32796
#define ID_VIEW_DISPLAYNAME             32797
#define ID_VIEW_ICON                    32798
#define ID_VIEW_                        32799
#define ID_ICONMEANING_SERVICETYPE      32800
#define ID_ICONMEANING_SERVICESTATE     32801
#define ID_VIEW_ACCOUNTNAME             32802
#define ID_VIEW_REFRESH32803            32803

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        218
#define _APS_NEXT_COMMAND_VALUE         32804
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
