// srvman.h
